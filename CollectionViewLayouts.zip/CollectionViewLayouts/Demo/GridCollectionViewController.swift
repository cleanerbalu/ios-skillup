//
//  GridCollectionViewController.swift
//  Demo
//
//  Created by Oleh Sannikov on 26.01.15.
//  Copyright (c) 2015 Oleh Sannikov. All rights reserved.
//

import UIKit

class GridCollectionViewController: BaseCollectionViewController {
    
}
